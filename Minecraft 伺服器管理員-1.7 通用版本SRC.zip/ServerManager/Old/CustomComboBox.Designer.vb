﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CustomComboBox
    Inherits System.Windows.Forms.ComboBox

    'Control 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為控制項設計工具的必要項
    Private components As System.ComponentModel.IContainer

    ' 注意: 以下為元件設計工具的所需的程序
    ' 您可以使用元件設計工具進行修改。請不要使用程式碼編輯器
    ' 進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

End Class

