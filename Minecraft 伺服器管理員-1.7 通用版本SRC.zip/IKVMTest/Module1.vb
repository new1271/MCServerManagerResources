﻿Module Module1

    Sub Main()
        Console.Write("選擇要開啟的JAR檔案：")
        Dim path As String = Console.ReadLine
        Console.Write("Java 參數：")
        Dim args As String = Console.ReadLine

    End Sub

End Module
