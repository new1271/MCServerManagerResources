﻿Namespace JsonServer.Enums
    Public Enum ErrorCodes
        Unknown
        LoginErrorByUser
        LoginErrorByAlreadyLogin
        LoginErrorByFile
        ServerExists
        SolutionExists
    End Enum
End Namespace
