﻿Public Class GeneratorSettingInfo

End Class
