﻿Public Interface IManagerGUI
End Interface
